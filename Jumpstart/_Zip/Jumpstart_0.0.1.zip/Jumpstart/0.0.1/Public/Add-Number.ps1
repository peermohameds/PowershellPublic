# .ExternalHelp Jumpstart-help.xml
function Add-Number {
    Param([int]$A, [int]$B)
    $A+$B
}
