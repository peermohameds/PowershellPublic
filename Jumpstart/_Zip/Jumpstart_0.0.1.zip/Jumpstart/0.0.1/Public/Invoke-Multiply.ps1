# .ExternalHelp Jumpstart-help.xml
Function Invoke-Multiply{
    Param([int]$A, [int]$B)
    $A * $B
}