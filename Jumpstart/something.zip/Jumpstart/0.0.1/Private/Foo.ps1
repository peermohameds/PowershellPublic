function Sample {
    param (
    )
    "Hello World"
}